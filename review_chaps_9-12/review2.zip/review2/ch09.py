"""Review of Chapter 9: Sequences.

Author: YOUR NAME
Version: THE DATE
"""


def indent_stars(text):
    """Add four spaces to lines that start with "* ".

    Args:
        text (str): Multi-line string representing notes.

    Returns:
        text: The same notes with all "*" lines indented.
    """


def unindent_stars(text):
    """Remove four spaces from lines that start with "    * ".

    Args:
        text (str): Multi-line string representing notes.

    Returns:
        text: The same notes with all "*" lines unindented.
    """
