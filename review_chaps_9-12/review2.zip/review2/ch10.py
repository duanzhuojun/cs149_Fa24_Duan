"""Review of Chapter 10: File I/O.

Author: YOUR NAME
Version: THE DATE
"""


def search_file(path, term):
    """Search a file for the given term.

    Args:
        path (str): The path of the file to search.
        term (str): The text to search for in the file.

    Returns:
        int, int: The line number and column of the term,
                  or None if the term is not found.
    """


def strip_file(path):
    """Remove whitespace from the end of each line in a file.

    Args:
        path (str): Location of the file to strip whitespace.
    """
