"""Review of Chapter 12: Recursion.

Author: YOUR NAME
Version: THE DATE
"""


def search_json(data, term, expr="data"):
    """Search a json object for the given term.

    Args:
        data (any): The object to search recursively.
        term (str): The text to search for in the object.
        expr (str): Python expression of the current data.

    Returns:
        str: The value of expr if term is found, else None.
    """

    # Base case: found the search term
    if isinstance(data, str):
        pass  # TODO return the current expression if term is found in the string data

    # Recursive case: search the dictionary
    if isinstance(data, dict):
        for key, value in data.items():
            pass  # TODO recursively call search_json() and return the result if found

    # Recursive case: search the list
    if isinstance(data, list):
        for idx, value in enumerate(data):
            pass  # TODO recursively call search_json() and return the result if found
