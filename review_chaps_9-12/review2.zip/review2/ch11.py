"""Review of Chapter 11: Nested Data.

Author: YOUR NAME
Version: THE DATE
"""

from statistics import mean, median


def print_stats(label, strings):
    """Print statistics about the lengths of the strings.

    Output format:
    >>> print_stats("Letters:", {"A", "BB", "CCC", "DDD"})
    Letters: min = 1.0, median = 2.5, mean = 2.2, min = 3.0

    Args:
        label (str): The first line to print above the stats.
        strings (set): The strings to calculate the stats.
    """


def track_stats(tracks):
    """Analyze track names, artist names, and album titles.

    Args:
        tracks (list): Top 50 tracks from the last.fm API.
    """
